# Problem 4
## Active Directory

### Efficiency

n here is the depth of the user location from the root parent till final group, it would also be the size of the stack for recursive calls.

- space   O(n)
- time    O(n)

Nothing is stored so space complexity is O(1).
Time complexity is O(n) as it is required to traverse all subfolders.

### Code Design

Similar to the Problem #2. I also have a feeling that I do not see a catch.