# Problem 5
## Blockchain

### Efficiency

- space   O(n)
- time    O(1)

To enqueue the complexity is of course O(1) as there are look-ups with traversals.

### Code Design

This was a confusing problem defintion. I am still not sure if I did what was required to pass.